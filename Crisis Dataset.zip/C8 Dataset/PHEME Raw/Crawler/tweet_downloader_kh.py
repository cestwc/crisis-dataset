#!//usr/bin/env python
"""
Description: 
    Download tweets using tweet ID, downloaded from https://noisy-text.github.io/files/tweet_downloader.py
    
Usage example (in windows):
    python tweet_downloader_kh.py --credentials cred.txt --inputfile en-scheme-annotations --skipline 0

Inputfile contains training/validation data whose first column is tweetID

credentials.txt stores the Twitter API keys and secrects in the following order:
consumer_key
consumer_secret
access_token
access_token_secret

Required Python library: 
    ujson, twython and twokenize (https://github.com/myleott/ark-twokenize-py)

An example output with whitespace tokenised text and tweet id in JSON format
    {"text":"@SupGirl whoaaaaa .... childhood flashback .","id_str":"470363741880463362"}
"""

try:
    import ujson as json
except ImportError:
    import json
import sys
import time
import datetime
import argparse
from twython import Twython, TwythonError
from collections import OrderedDict
import csv

MAX_LOOKUP_NUMBER = 100
#SLEEP_TIME = 15 + 1
SLEEP_TIME = 5
twitter = None
arguments = None
tid_list = None

def init():
    global twitter, arguments, tid_list, tid_label

    parser = argparse.ArgumentParser(description = "A simple tweet downloader for WNUT-NORM shared task.")
    parser.add_argument('--credentials', type=str, required = True, help = '''\
        Credential file which consists of four lines in the following order:
        consumer_key
        consumer_secret
        access_token
        access_token_secret
        ''')
    parser.add_argument('--inputfile', type=str, required = True, help = 'Input file: one tweet id per line')
    parser.add_argument('--skipline', type=int, required = True, help = 'Input file number of lines to skip')
    arguments = parser.parse_args()

    credentials = []
    with open(arguments.credentials) as fr:
        for l in fr:
            credentials.append(l.strip())
    twitter = Twython(credentials[0], credentials[1], credentials[2], credentials[3])

    tid_list = []
    tid_label = {}
    with open(arguments.inputfile) as fr:
        for l in fr:
            if l[0] == "#":
                continue
            jobj = json.loads(l.strip())
            tid = jobj['tweetid']
            label = jobj['event']
            #tid = jobj
            tid_list.append(tid)
            tid_label[tid] = label
            
    if ( arguments.skipline != 0 ):
        tid_list = tid_list[arguments.skipline:]

def download():
    global twitter, arguments, tid_list, tid_label
    #with open(arguments.inputfile + ".JsonOut", "w") as fwJson, open(arguments.inputfile + ".TweetOut", "w") as fwTweet:
    with open(arguments.inputfile + ".JsonOut", "a") as fwJson, open(arguments.inputfile + ".TweetOut", "a") as fwTweet, open(arguments.inputfile + ".TweetOut.csv", 'a', encoding='utf-8') as fwCSV:
        
        tid_number = len(tid_list)
        max_round = tid_number // MAX_LOOKUP_NUMBER + 1

        fieldnames = ['event', 'tweetID', 'text']
        writer = csv.DictWriter(fwCSV, fieldnames=fieldnames)
        writer.writeheader()
	
        for i in range(max_round):
            tids = tid_list[i * MAX_LOOKUP_NUMBER : (i + 1) * MAX_LOOKUP_NUMBER]
            time.sleep(SLEEP_TIME)
            jobjs = []
            jobjs = twitter.lookup_status(id = tids)
            for jobj in jobjs:
                fwJson.write(json.dumps(jobj))
                fwJson.write("\n")
                tweet = jobj["text"]
                tid = jobj["id_str"]
                label = tid_label[tid]
                dic_tweet = (('label', label), ('tweet_id', tid), ('text', tweet))
                fwTweet.write(json.dumps(OrderedDict(dic_tweet)))
                fwTweet.write("\n")
                writer.writerow({'event':label, 'tweetID':tid, 'text':tweet})

def main():
    print("Start time: " +str(datetime.datetime.now().time()))
    init()
    download()
    print("Completed time: " +str(datetime.datetime.now().time()))

if __name__ == "__main__":
    main()
